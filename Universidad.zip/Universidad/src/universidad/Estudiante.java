package universidad;

public class Estudiante {
    private String nombre;
    private String id;
    private double promedio;
    private String carrera;

    public Estudiante(String nombre, String id, double promedio, String carrera) {
        this.nombre = nombre;
        this.id = id;
        this.promedio = promedio;
        this.carrera = carrera;
    }

    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public double getPromedio() {
        return promedio;
    }

    public String getCarrera() {
        return carrera;
    }
}
