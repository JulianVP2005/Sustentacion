package universidad;

import java.util.ArrayList;
import java.util.List;

public interface Observador {
    void notificar(String mensaje);
}

class NotificacionEmail implements Observador {
    @Override
    public void notificar(String mensaje) {
        System.out.println("Enviando Email: " + mensaje);
    }
}

class NotificacionSMS implements Observador {
    @Override
    public void notificar(String mensaje) {
        System.out.println("Enviando SMS: " + mensaje);
    }
}

class GestorNotificaciones {
    private List<Observador> observadores = new ArrayList<>();

    public void agregarObservador(Observador observador) {
        observadores.add(observador);
    }

    public void notificarTodos(String mensaje) {
        for (Observador observador : observadores) {
            observador.notificar(mensaje);
        }
    }
}
