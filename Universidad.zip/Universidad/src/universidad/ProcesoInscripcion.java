package universidad;

public abstract class ProcesoInscripcion {
    public final void realizarInscripcion(Estudiante estudiante, String programaAcademico) {
        validarEstudiante(estudiante);
        registrarPrograma(estudiante, programaAcademico);
        confirmarInscripcion(estudiante, programaAcademico);
    }

    protected abstract void validarEstudiante(Estudiante estudiante);

    protected abstract void registrarPrograma(Estudiante estudiante, String programaAcademico);

    private void confirmarInscripcion(Estudiante estudiante, String programaAcademico) {
        System.out.println("Inscripción confirmada: Estudiante " + estudiante.getNombre() + " | Cédula: " + estudiante.getId() + " | Carrera: " + estudiante.getCarrera() + " | Programa Académico: " + programaAcademico);
    }
}

class InscripcionAcademica extends ProcesoInscripcion {
    @Override
    protected void validarEstudiante(Estudiante estudiante) {
        System.out.println("Validando estudiante: " + estudiante.getNombre());
    }

    @Override
    protected void registrarPrograma(Estudiante estudiante, String programaAcademico) {
        GestorInscripciones.getInstance().inscribirEstudiante(estudiante, programaAcademico);
    }
}
