package universidad;

import java.util.ArrayList;
import java.util.List;

public class GestorInscripciones {
    private static GestorInscripciones instancia;
    private List<String> inscripciones;

    private GestorInscripciones() {
        inscripciones = new ArrayList<>();
    }

    public static GestorInscripciones getInstance() {
        if (instancia == null) {
            instancia = new GestorInscripciones();
        }
        return instancia;
    }

    public void inscribirEstudiante(Estudiante estudiante, String programaAcademico) {
        inscripciones.add("Estudiante: " + estudiante.getNombre() + " | Cédula: " + estudiante.getId() + " | Carrera: " + estudiante.getCarrera() + " | Programa Académico: " + programaAcademico);
        System.out.println("Inscripción exitosa: " + estudiante.getNombre() + " | Cédula: " + estudiante.getId() + " | Carrera: " + estudiante.getCarrera() + " | Programa Académico: " + programaAcademico);
    }

    public List<String> getInscripciones() {
        return inscripciones;
    }
}
