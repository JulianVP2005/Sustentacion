package universidad;

import java.util.Scanner;

public class UniversidadMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Estudiante estudiante = null;
        int opcion = 0;

        do {
            System.out.println("\n--- Menú ---");
            System.out.println("1. Inscribir estudiante en carrera");
            System.out.println("2. Solicitar beca y pagar matrícula");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // Crear Estudiante
                    scanner.nextLine();  // Limpiar el buffer
                    System.out.print("Ingrese el nombre del estudiante: ");
                    String nombreEstudiante = scanner.nextLine();
                    System.out.print("Ingrese el ID del estudiante: ");
                    String idEstudiante = scanner.nextLine();
                    System.out.print("Ingrese el promedio del estudiante: ");
                    double promedioEstudiante = scanner.nextDouble();
                    scanner.nextLine();  // Limpiar el buffer

                    // Lista de carreras disponibles
                    System.out.println("Seleccione la carrera para inscribirse:");
                    System.out.println("1. Ingeniería de Sistemas");
                    System.out.println("2. Derecho");
                    System.out.println("3. Medicina");
                    System.out.println("4. Psicología");
                    System.out.println("5. Administración de Empresas");
                    System.out.print("Seleccione una opción: ");
                    int opcionCarrera = scanner.nextInt();
                    String carreraEstudiante = "";

                    // Asignar la carrera seleccionada
                    switch (opcionCarrera) {
                        case 1:
                            carreraEstudiante = "Ingeniería de Sistemas";
                            break;
                        case 2:
                            carreraEstudiante = "Derecho";
                            break;
                        case 3:
                            carreraEstudiante = "Medicina";
                            break;
                        case 4:
                            carreraEstudiante = "Psicología";
                            break;
                        case 5:
                            carreraEstudiante = "Administración de Empresas";
                            break;
                        default:
                            System.out.println("Opción no válida.");
                            break;
                    }

                    // Crear el estudiante con la carrera seleccionada
                    estudiante = new Estudiante(nombreEstudiante, idEstudiante, promedioEstudiante, carreraEstudiante);

                    // Inscripción a carrera académica
                    ProcesoInscripcion inscripcion = new InscripcionAcademica();
                    inscripcion.realizarInscripcion(estudiante, carreraEstudiante);
                    break;

                case 2:
                    if (estudiante == null) {
                        System.out.println("¡Primero debe inscribir al estudiante!");
                    } else {
                        // Solicitar beca y calcular descuento
                        System.out.print("Ingrese el costo base de la matrícula: ");
                        double costoBase = scanner.nextDouble();
                        SolicitudBeca solicitudBeca = new SolicitudBeca(estudiante);
                        PagoMatricula pago = solicitudBeca.calcularBeca(costoBase);
                        System.out.println("Costo final de la matrícula: $" + pago.calcularCosto());

                        // Notificaciones
                        GestorNotificaciones gestorNotificaciones = new GestorNotificaciones();
                        gestorNotificaciones.agregarObservador(new NotificacionEmail());
                        gestorNotificaciones.agregarObservador(new NotificacionSMS());
                        gestorNotificaciones.notificarTodos("El estudiante " + estudiante.getNombre() + " ha completado su inscripción.");
                    }
                    break;

                case 3:
                    System.out.println("¡Hasta luego!");
                    break;

                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
                    break;
            }

        } while (opcion != 3);

        scanner.close();
    }
}
