package universidad;

public abstract class PagoMatricula {
    public abstract double calcularCosto();
}

class MatriculaBase extends PagoMatricula {
    private double costo;

    public MatriculaBase(double costo) {
        this.costo = costo;
    }

    @Override
    public double calcularCosto() {
        return costo;
    }
}

class DescuentoBeca extends PagoMatricula {
    private PagoMatricula matriculaBase;
    private double porcentajeDescuento;

    public DescuentoBeca(PagoMatricula matriculaBase, double porcentajeDescuento) {
        this.matriculaBase = matriculaBase;
        this.porcentajeDescuento = porcentajeDescuento;
    }

    @Override
    public double calcularCosto() {
        return matriculaBase.calcularCosto() * (1 - porcentajeDescuento / 100);
    }
}
