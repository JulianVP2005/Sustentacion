package universidad;

import java.util.Scanner;

public class SolicitudBeca {
    private Estudiante estudiante;

    public SolicitudBeca(Estudiante estudiante) {
        this.estudiante = estudiante;
    }

    public PagoMatricula calcularBeca(double costoBase) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("¿Qué tipo de beca desea solicitar?");
        System.out.println("1. Beca Deportiva (30% descuento)");
        System.out.println("2. Beca Académica (50% descuento)");
        int opcion = scanner.nextInt();

        if (opcion == 1 && estudiante.getPromedio() >= 40) {
            System.out.println("Aplicando Beca Deportiva (30% de descuento) para " + estudiante.getNombre());
            return new DescuentoBeca(new MatriculaBase(costoBase), 30);
        } else if (opcion == 2 && estudiante.getPromedio() >= 45) {
            System.out.println("Aplicando Beca Académica (50% de descuento) para " + estudiante.getNombre());
            return new DescuentoBeca(new MatriculaBase(costoBase), 50);
        } else {
            System.out.println("No se aplica beca para " + estudiante.getNombre());
            return new MatriculaBase(costoBase);
        }
    }
}

